package com.example.musicos;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;


public class ProfileSingerActiviy extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profilesinger);
        TextView nameTexView =findViewById(R.id.nameTexView);

        String name = "name no set";
        Bundle extras  = getIntent().getExtras();
        if (extras != null){
            name = extras.getString("name");
        }
        nameTexView.setText(name);
    }
}
